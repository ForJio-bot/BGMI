<?php
$emailku = 'reaperjomd@gmail.com';
?>